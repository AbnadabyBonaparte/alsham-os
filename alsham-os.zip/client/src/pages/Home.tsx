import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { TaliaChat } from "@/components/TaliaChat";
import { NexusVisualization } from "@/components/NexusVisualization";
import { getLoginUrl } from "@/const";
import { Sparkles, Brain, Network, Zap, ArrowRight, LogOut } from "lucide-react";
import { motion } from "framer-motion";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => {
      toast.success("Logout realizado com sucesso");
      window.location.reload();
    },
    onError: () => {
      toast.error("Erro ao fazer logout");
    },
  });

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="inline-block h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
          <p className="text-muted-foreground">Carregando ALSHAM OS...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen relative overflow-hidden">
        {/* Animated background */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-3xl animate-pulse-slow"></div>
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-secondary/20 rounded-full blur-3xl animate-pulse-slow delay-1000"></div>
        </div>

        {/* Content */}
        <div className="relative z-10 container mx-auto px-4 py-20">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center max-w-5xl mx-auto space-y-8"
          >
            {/* Logo/Icon */}
            <motion.div
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="inline-flex items-center justify-center w-24 h-24 rounded-full gradient-primary glow"
            >
              <Brain className="w-12 h-12 text-white" />
            </motion.div>

            {/* Title */}
            <div className="space-y-4">
              <h1 className="text-6xl md:text-8xl font-bold tracking-tight">
                <span className="gradient-text">ALSHAM OS</span>
              </h1>
              <p className="text-2xl md:text-3xl text-muted-foreground font-light">
                Superinteligência Corporativa
              </p>
            </div>

            {/* Description */}
            <p className="text-lg md:text-xl text-foreground/80 max-w-3xl mx-auto leading-relaxed">
              Comande uma força de trabalho digital de{" "}
              <span className="text-primary font-semibold">161 agentes de IA especializados</span>{" "}
              através de uma única conversa. Transforme ideias em realidade com o poder de
              orquestração inteligente.
            </p>

            {/* Features */}
            <div className="grid md:grid-cols-3 gap-6 mt-12 max-w-4xl mx-auto">
              {[
                {
                  icon: Sparkles,
                  title: "Interface Conversacional",
                  description: "Converse com Tália X.1 e veja a mágica acontecer",
                },
                {
                  icon: Network,
                  title: "8 Clusters Especializados",
                  description: "De desenvolvimento a sustentabilidade",
                },
                {
                  icon: Zap,
                  title: "Execução Autônoma",
                  description: "Projetos complexos rodando em piloto automático",
                },
              ].map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.4 + index * 0.1 }}
                  className="glass p-6 rounded-2xl hover:scale-105 transition-transform"
                >
                  <feature.icon className="w-10 h-10 text-primary mb-4 mx-auto" />
                  <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </motion.div>
              ))}
            </div>

            {/* CTA */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.8 }}
              className="pt-8"
            >
              <Button
                size="lg"
                className="gradient-primary hover:opacity-90 transition-opacity text-lg px-8 py-6 glow"
                onClick={() => (window.location.href = getLoginUrl())}
              >
                Entrar no Santuário Digital
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <p className="text-sm text-muted-foreground mt-4">
                Faça login com sua conta Manus para começar
              </p>
            </motion.div>
          </motion.div>
        </div>

        {/* Footer */}
        <div className="absolute bottom-8 left-0 right-0 text-center text-sm text-muted-foreground">
          <p>Powered by Next.js, TypeScript & LangGraph</p>
        </div>
      </div>
    );
  }

  // Authenticated view - Santuário Digital
  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="glass border-b border-border/50 sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full gradient-primary flex items-center justify-center glow">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold gradient-text">ALSHAM OS</h1>
                <p className="text-xs text-muted-foreground">Santuário Digital</p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-sm font-medium">{user?.name}</p>
                <p className="text-xs text-muted-foreground">{user?.email}</p>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={handleLogout}
                disabled={logoutMutation.isPending}
              >
                <LogOut className="h-4 w-4 mr-2" />
                Sair
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex">
        {/* Chat Area */}
        <div className="flex-1 flex flex-col">
          <TaliaChat />
        </div>

        {/* Sidebar - Nexus Visualization */}
        <aside className="w-96 glass border-l border-border/50 p-6 hidden xl:block">
          <NexusVisualization />
        </aside>
      </main>
    </div>
  );
}
