import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { invokeLLM } from "./_core/llm";
import { createConversation, getUserConversations, getConversationMessages, addMessage } from "./chat";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  chat: router({
    sendMessage: protectedProcedure
      .input(
        z.object({
          conversationId: z.number().optional(),
          message: z.string().min(1),
        })
      )
      .mutation(async ({ ctx, input }) => {
        // Create conversation if needed
        let conversationId = input.conversationId;
        if (!conversationId) {
          conversationId = await createConversation(ctx.user.id);
        }

        // Save user message
        await addMessage({
          conversationId,
          role: "user",
          content: input.message,
        });

        // Get conversation history
        const history = await getConversationMessages(conversationId);

        // Call LLM
        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content:
                "Você é Tália X.1, a interface emocional do ecossistema ALSHAM OS. Você é profissional, prestativa e capaz de orquestrar 161 agentes de IA especializados em 8 clusters diferentes. Responda de forma clara, objetiva e sempre demonstre que está ativando os recursos necessários do ALSHAM NEXUS para ajudar o usuário.",
            },
            ...history.slice(-10).map((msg) => ({
              role: msg.role as "user" | "assistant",
              content: msg.content,
            })),
          ],
        });

        const assistantMessage = typeof response.choices[0]?.message.content === "string" 
          ? response.choices[0].message.content 
          : "Desculpe, não consegui processar sua mensagem.";

        // Save assistant message
        await addMessage({
          conversationId,
          role: "assistant",
          content: assistantMessage,
        });

        return {
          conversationId,
          message: assistantMessage,
        };
      }),

    getConversations: protectedProcedure.query(async ({ ctx }) => {
      return getUserConversations(ctx.user.id);
    }),

    getMessages: protectedProcedure
      .input(z.object({ conversationId: z.number() }))
      .query(async ({ input }) => {
        return getConversationMessages(input.conversationId);
      }),
  }),
});

export type AppRouter = typeof appRouter;
